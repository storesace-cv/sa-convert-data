# Phase 2 — Core Pipeline

Scope:
- Normalization of inputs (databases/)
- Classification rules (rules/)
- Deduplication (≥85%) across *all* stores
- Excel export with rule columns

Exit criteria:
- Unit tests covering normalization and dedup
- Export workbook validated on sample datasets
